

//variables for original code

var sound, amplitude, cnv;

function preload(){
  sound = loadSound('onmymind.mp3');
}

var x = 300;
var y = 200;
var d = 90;
var state = false;
var A = 20;
var s;



 


function setup() {
  frameRate(20);
  cnv = createCanvas(650,650);
  amplitude = new p5.Amplitude();
  sound.play();
}

function draw() {
  var level = amplitude.getLevel();
  var size = map(level, 0, 1, 0, 200);

  background(mouseX+(size*2),mouseY+(size*2),200);
  fill(random(110,250),random(110,250),random(110,250));

  //E1
  ellipse(x, 200, d, d+(size+=.5));
  
  //E2
  ellipse(x/2, 200, d+(size+=.5), d);
  
  //E3
  ellipse(x*1.5, 200, d+(size+=.5), d);
  
  strokeWeight(10);
  
  line(size+100, 425, 520-size, 425);
  line(size+120, mouseY, 500-size, mouseX);
  line(size+150, 385, 480-size, 385);
  line(size+200, 345, 450-size, 345);



  //Little drawing circles{
 ellipse(mouseX,mouseY,20,20);
}


